<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductModel extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//$this->load->view('welcome_message');
	}


	public function saveData(){

	$prodlist=json_decode($_POST['prodlist']);




$myresult='';

$count=0;
foreach ($prodlist as $myrow) {
//	var_dump($myrow);
$username=$myrow->username;
 $name=$myrow->name;
$passwrord=$myrow->password;
  $email=$myrow->email;
$pname=$myrow->pname;
  $price=$myrow->price;
 $qty=$myrow->qty;
  $discount=$myrow->discount;
$type=$myrow->type;
$total=$myrow->total;
	$mydata = array(
        'username' => $username,//$this->input->post('username')
       'pname' => $pname,
        'price' => $price,
         'qty' => $qty,
          'discount' => $discount,
          'type'=>  $type,
          'total'=>  $total
    );
//var_dump($mydata );
 
	 $this->load->database();

if($count==0){
$regdata = array(
        'username' => $username,//$this->input->post('username')
         'name' => $name,
          'email' => $email,
           'password' => $passwrord
       );

$myresult=$this->db->insert('register', $regdata);
}
$count++;



   $myresult=$this->db->insert('cust_orders', $mydata);




	}






if($myresult==true){
	return true;
}else{
return  $this->db->_error_message();  
}
}


}