<?php
header('Access-Control-Allow-Origin: *');
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <!--<script src="https://code.jquery.com/jquery-3.5.0.js"></script>-->
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<!-- --><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<meta charset="utf-8">
	<title>Add Product</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}
 label{
 	min-width: 150px
 }
	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	th{
		background: beige;
	}
 table td,th{
 	text-align: center;
 }
	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}

	input,select{

		max-height: 27px;
		margin-left: 5px;
		min-width:200px;
	}
	</style>
</head>
<body>

<div id="container">
	<h1><center>Add Product</center></h1>
	<form action="<?php echo base_url()?>index.php/Product/save" method='post'>
	<div id="body" class="row">
	
		<div class="col-md-12 card">
		<label>Name:</label><input type='text' name='name' id='name' required><br>
		<label>Username:</label><input type='text' name='username' id='username' required><br>
		<label>Email :</label><input type='email' name='email' id='email' required><br>
		<label>Password:</label><input type='Password' name='password' id='password' required><br>
         <br>
         <br>


		<!--<label>Product Name:</label><input type='text' name='pname' id='pname' required><br>
		<label>Product Price:</label><input type='number' name='price' id='price' required><br>
		<label>Quantity :</label><input type='number' name='qty' id='qty' required><br>
		<label>Product Type:</label><select name='type'  id='type' required>
			<option >select</option>
			<option value='Flat'>Flat</option>
			<option value='Discount'>Discount</option>

		</select><br>
		<label>Discount(Rs.) :</label><input type='number' name='discount' id='discount'><br>
		<div></div><label></label>-->

		<button type='button' id='btnadd' style="margin-left: 10px" onclick='javascript:validate()'>Add</button>
</div>
	</div>
	<!--<tr id='empty'><td colspan="4" style="height: 100px">No products added</td></tr>-->
<div id="body" class="row">
<div class="col-md-12 card">
<table border="1" width="80%" >

			<th>Product Name</th>
			<th>Product Price</th>
			<th>Quantity </th>
			<th>Total </th>
			<th>Type </th>
			<th>Discount</th>
			<th>action</th>
		</table>
</div>
 	<button type='button' id='btnsubmit' style="margin-left: 10px" >submit</button>
</div>
	</form>

	<p class="footer"><center>Developed By Rahul Badrike<br>Email:rrbadrike@gmail.com</center> <br>

	</p>
</div>

</body>
<script type="text/javascript">



$(document).ready(function () {
//    $('div').on('click', function() {
 //       alert("Clicked: " + $(this).html());
  //  });



//prince and qty
    $(document).on("change hover focusin", " .myqty" ,function(){
var qty=$(this).val();
	if(qty>0){	
	var price=$(this).parent().prev().find('.price').val();
	$(this).parent().parent().find('.total').val(qty*price);
            }
	});




//flat and dicout
	   $(document).on("change mouseover focusout", ".type" ,function(){
//alert($(this).val());
	if($(this).val()=='Flat'){
			//	$('#discount').val('');
			//$('#discount').attr('readonly','readonly');
				$(this).parent().next().find('.disc').attr('readonly','readonly');
		}else if($(this).val()=='Discount'){
		$(this).parent().next().find('.disc').attr('value','0');
			$(this).parent().next().find('.disc').removeAttr('readonly');
		}
	});





});


	function validate(){
/*
var username=$('#username').val();
var name=$('#name').val();
var email=$('#email').val();
var password=$('#password').val();

var pname = $('input:text.pname');
var price = $('input .price');
var qty = $('input .qty');
var discount = $('input .discount');

var pnamelist=[];
for(var i=0;i<pname.length;i++){
	//console.log(pname[i].value);
	pnamelist.push(pname[i].value);
}
console.log(pnamelist);*/


/*
 var product={username:username, email:email, password:password, name:name,pname:pnamelist,price:price,qty:qty,discount:discount};
 productlist.push(product);*/



 //JSON.stringify(productlist);
$('#empty').remove();
 $('table').append("<tr><td><input type='text' name='pname[]' class='pname' required></td><td><input type='number' name='price[]' class='price' required></td><td><input type='number' class='myqty' name='qty[]' required></td><td><input type='number' name='total[]' class='total' readonly></td><td><select name='type[]'  class='type' >"+
			
			"<option value='Flat'>Flat</option>"+
			"<option value='Discount'>Discount</option>"+

		"</select></td><td><input type='text' class='disc' name='discount[]'></td><td><button type='button' class='del'>delete</button></td></tr>");


//console.log(JSON.stringify(productlist));

	}
let productlist =[];

/*	$('#btnadd').click(
function(){

var username=$('#username').val();
var name=$('#name').val();
var email=$('#email').val();
var password=$('#password').val();

var pname=$('#pname').val();
var price=$('#price').val();
var qty=$('#qty').val();
var discount=$('#discount').val();


 var product={username:username, email:email, password:password, name:name,pname:pname,price:price,qty:qty,discount:discount};
 productlist.push(product);

 //JSON.stringify(productlist);

 $('table').append("<tr><td>"+pname+"</td><td>"+price+"</td><td>"+qty+"</td><td>"+discount+"</td></tr>");


//console.log(JSON.stringify(productlist));

});*/



	$('#btnsubmit').click(
function(){

var username=$('#username').val();
var name=$('#name').val();
var email=$('#email').val();
var password=$('#password').val();


if(username=='' || name=='' || email=='' || password==''){
alert("plz enter all fields");
}else{

var pname = $('.pname');
var price = $('.price');
var qty = $('.myqty');
var discount = $('.disc');
var type = $('.type');
var total = $('.total');
var pnamelist=[];
for(var i=0;i<pname.length;i++){
	//console.log(discount[i].value);
	//pnamelist.push(pname[i].value);

var product={username:username, email:email, password:password, name:name,pname:pname[i].value,price:price[i].value,qty:qty[i].value,discount:discount[i].value,type:type[i].value,total:total[i].value};
 productlist.push(product);
}


console.log(JSON.stringify(productlist));


	var url='<?php echo base_url()?>';
	if(productlist.length>0){
$.post(url+'index.php/Product/save',{prodlist:JSON.stringify(productlist)},function(mydata){
	alert(mydata);

	 productlist=[];//ckear list

});
}else{
	alert("plz add products first");
}

}


});




	$('#type').change(function(){

		if($(this).val()=='Flat'){
				$('#discount').val('');
			$('#discount').attr('readonly','readonly');
		}else if($(this).val()=='Discount'){

			$('#discount').removeAttr('readonly');
		}
	})

//dynamic element 
  $(document).on("click", ".del" ,function(){

$(this).parent().parent().remove();
  });





</script>
</html>